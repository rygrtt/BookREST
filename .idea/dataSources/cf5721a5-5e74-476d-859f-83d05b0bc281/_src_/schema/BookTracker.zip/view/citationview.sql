CREATE VIEW citationview AS
  SELECT
    `B`.`title`          AS `title`,
    `B`.`publisher`      AS `publisher`,
    `B`.`yearPublished`  AS `yearPublished`,
    `B`.`edition`        AS `edition`,
    `B`.`bookID`         AS `bookID`,
    `N`.`NoteID`         AS `noteID`,
    `N`.`pageNoteBegins` AS `pageNoteBegins`,
    `N`.`pageNoteEnds`   AS `pageNoteEnds`,
    `A`.`lastName`       AS `lastName`,
    `A`.`firstName`      AS `firstName`
  FROM (((`booktracker`.`book` `B`
    JOIN `booktracker`.`note` `N` ON ((`B`.`bookID` = `N`.`Book_bookID`))) JOIN `booktracker`.`book_has_author`
      ON ((`B`.`bookID` = `booktracker`.`book_has_author`.`Book_bookID`))) JOIN `booktracker`.`author` `A`
      ON ((`booktracker`.`book_has_author`.`Author_authorID` = `A`.`authorID`)));
